package com.algo.done.dto;

import java.util.List;

public class TempDataForPartial {
	
	List<Integer> temp;

	public List<Integer> getTemp() {
		return temp;
	}

	public void setTemp(List<Integer> temp) {
		this.temp = temp;
	}

	
	

}
